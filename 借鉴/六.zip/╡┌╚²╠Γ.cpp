#include<iostream>
#include<list>
#include<string>

using namespace std;

typedef list<int> Integerlist;

int main() {
	Integerlist integerlist;
	int a;
	
	cout << "����ʮ��������" << endl;
	
	
	for (int i = 0; i < 10; i++) {
		cin >> a;
		integerlist.push_front(a);
	}

	while (!integerlist.empty()) {
		cout << integerlist.front() << " ";
		integerlist.pop_front();
	}
	cout << endl;
}